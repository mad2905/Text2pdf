import os
from multiprocessing import Process
import pytesseract
from pdf2image import convert_from_path
import psycopg2
import time
pytesseract.pytesseract.tesseract_cmd ="C:\\Program Files\\Tesseract-OCR\\tesseract.exe"
#tesseract_path = 'C:\\Program Files\\Tesseract-OCR'
class PDFConverter:
    def __init__(self, pdf_folder, output_folder):
        self.pdf_folder = pdf_folder
        self.output_folder = output_folder
        #self.tesseract_path='C:\\Program Files\\Tesseract-OCR'



    def convert_pdf(self, id,pdf_file):

        pdf_path=pdf_file

        if not self.is_pdf_file(pdf_path):
            print(f"Error: {pdf_file} is not a PDF file.")
            return

        start_time = time.time()

        images = convert_from_path(pdf_path,poppler_path=r"C:\Program Files (x86)\poppler-23.05.0\Library\bin",dpi=250)
        text = ""



        page_count=0


        for image in images:
            page_text = pytesseract.image_to_string(image, lang='eng')
            text += page_text + "\n"
            #text += page_text + "\n"
            if text.strip():
                page_count+=1
        filename = os.path.splitext(pdf_file)[0]
        output_path = self.get_unique_filename(filename)
        try:
            with open(output_path, 'w', encoding='utf-8') as file:
                file.write(text)
            print(f"Converted {pdf_file} to text: {output_path}")
        except Exception as e:
            print(f"Error converting {pdf_file}: {str(e)}")
        file_siz=os.path.getsize(pdf_path)


        execution_time = time.time() - start_time
        db_params = {
            'host': 'localhost',
            'database': 'tablefact',
            'user': 'postgres',
            'password': 'qwertyuiop',
            'port': 5432
        }
        connection = psycopg2.connect(**db_params)
        updator = connection.cursor()


        updator.execute(""" UPDATE "PDFCONV" SET opp= %s,file_sizee=%s,page_count=%s,execution_timee=%s WHERE id= %s; """,(output_path,file_siz,page_count,execution_time,id))
        connection.commit()

        updator.close()
        connection.close()

    def is_pdf_file(self, file_path):
        return os.path.isfile(file_path) and file_path.lower().endswith('.pdf')

    def get_unique_filename(self, filename):
        counter = 1
        base_name = os.path.basename(filename)
        file_name, file_extension = os.path.splitext(base_name)
        output_file = os.path.join(self.output_folder, f"{file_name}.txt")

        while os.path.exists(output_file):
            output_file = os.path.join(self.output_folder, f"{file_name}_{counter}.txt")
            counter += 1

        return output_file


    def convert_all(self):

        pdf_files=self.pdf_folder
        processes = [Process(target=self.convert_pdf, args=(key,value)) for key,value in pdf_files.items()]
        [process.start() for process in processes]
        [process.join() for process in processes]

        print("Conversion completed!")



if __name__ == '__main__':

    db_params = {
        'host': 'localhost',
        'database': 'tablefact',
        'user': 'postgres',
        'password': 'qwertyuiop',
        'port': 5432
    }
    connection = psycopg2.connect(**db_params)
    curr = connection.cursor()
    extractor=connection.cursor()

    #adding i/p file path to DB
    id=0
    folder_path = "C:\FACTENTRY\input"
    pdf_files = [file for file in os.listdir(folder_path) if file.endswith(".pdf")]
    for pdf_file in pdf_files:

        pdf_path = os.path.join(folder_path, pdf_file)

        id=id+1

        try:
            curr.execute("""INSERT INTO "PDFCONV" (id,ipp,opp,file_sizee,page_count,execution_timee) VALUES (%s,%s,%s,%s,%s,%s)""", (id,pdf_path,0,0,0,0))

        except:
             print("File already exists")
             connection.rollback()
        else:
            connection.commit()


    extractor.execute("""SELECT "ipp","id" FROM "PDFCONV" """)
    res=extractor.fetchall()
    pdf_ppath = [row[0] for row in res ]
    pdf_id=[row[1] for row in res]
    pdf_folder=pdf_ppath
    pdf_mappings = {row[1]: row[0] for row in res}

    output_folder ="C:\\FACTENTRY\\output"

    converter = PDFConverter(pdf_mappings, output_folder)
    converter.convert_all()